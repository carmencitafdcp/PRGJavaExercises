package ejercicios.ejercicio5;

public class RadioNegativoException extends NumberFormatException{
    public RadioNegativoException(String cad){
        super(cad);
    }
}