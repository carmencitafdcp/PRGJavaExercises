package ejercicios.ejercicio3;

import java.util.ArrayList;

public class Cadena {
    private ArrayList<Character> cadena = new ArrayList<>();

    public void setCadena(String cad) {
        if (cad == null) {
            throw new IllegalArgumentException("No se puede pasar cadena vacía, inténtalo de nuevo.");
        }
        for (int i = 0; i < cad.trim().length(); i++) {
            cadena.add(cad.trim().charAt(i));
        }
    }

    @Override
    public String toString() {
        String charAcadena = "";
        for (int i = 0; i < cadena.size(); i++) {
            charAcadena = charAcadena + cadena.get(i);
        }
        return charAcadena;
    }

    @Override
    public boolean equals(Object anObject) {
        if (anObject == null) {
            throw new IllegalArgumentException("El objeto pasado como parámetro no puede ser null.");
        }

        if (anObject instanceof Cadena) {
            Cadena cad = (Cadena) anObject; // Se crea un objeto de tipo cadena
            if (this.cadena.size() != cad.cadena.size()) { 
                /*Si el tamaño de la coleccion local no es igual no es igual al tamaño de la nueva coleccion cad...*/
                return false;
            }
            for (int i = 0; i < cadena.size(); i++) {
                if (!this.cadena.get(i).equals(cad.cadena.get(i))) {
                    // si no tienen los mismo caracteres en las mismas posiciones...
                    return false;
                }

            }
            return true;
        } else if (anObject instanceof String) {
            String nuevo = ((String) anObject).trim(); // Se crea un objeto de tipo String
            if (this.cadena.size() != nuevo.length()) {
                return false;
            }
            for (int i = 0; i < cadena.size(); i++) {
                if (!this.cadena.get(i).equals(nuevo.charAt(i))) {
                    return false;
                }
            }
            return true;
        } else if (anObject instanceof char[]) {
            char[] caracteres = (char[]) anObject; // Se crea un nuevo array
            if (this.cadena.size() != caracteres.length) {
                return false;
            }
            for (int i = 0; i < cadena.size(); i++) {
                if (!this.cadena.get(i).equals(caracteres[i])) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }

    public int eliminar(char caracter) {
        int cont = 0;
        for (int i = cadena.size(); i >= 0; i--) {
            if (cadena.get(i) == caracter) {
                cadena.remove(i);
                cont++;
            }
        }
        return cont;
    }
}