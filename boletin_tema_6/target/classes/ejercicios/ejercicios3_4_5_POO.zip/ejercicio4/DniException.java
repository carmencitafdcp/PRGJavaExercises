package ejercicios.ejercicio4;

public class DniException extends IllegalArgumentException {
    public DniException(String mensaje) {
        super(mensaje);
    }
}

