package ejercicios.ejercicio3;

import javax.swing.JFrame;

public class Principal {
    public static void main(String[] args) {
        Colores color = new Colores();
        color.setSize(400,300);
        color.setVisible(true);
        color.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
