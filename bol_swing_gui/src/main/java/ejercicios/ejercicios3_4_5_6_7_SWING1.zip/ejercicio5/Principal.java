package ejercicios.ejercicio5;

import javax.swing.JFrame;

public class Principal {
    public static void main(String[] args) {
        Tragaperrasv1 juego = new Tragaperrasv1();
        juego.setSize(230, 330);
        juego.setVisible(true);
        juego.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
