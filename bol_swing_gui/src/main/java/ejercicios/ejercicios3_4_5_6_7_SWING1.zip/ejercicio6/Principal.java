package ejercicios.ejercicio6;

import javax.swing.JFrame;
public class Principal {
    public static void main(String[] args) {
        Operaciones op = new Operaciones();
        op.setSize(400, 400);
        op.setVisible(true);
        op.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}  
