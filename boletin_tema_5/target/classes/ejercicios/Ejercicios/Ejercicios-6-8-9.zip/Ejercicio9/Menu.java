package ejercicios.Ejercicios.Ejercicio9;

import java.util.Scanner;

public class Menu {
    private ClassRoom c; // Me impide poner class así que se queda como c

    /**
     * Constructor de la clase Menu que crea un objeto de la clase ClassRoom con el constructor de dicha clase
     * donde se pasan la cantidad de estudiantes y la cantidad de materias. 
     * Además de que establece la cantidad de estudiantes y de materias.
     */
    public Menu() {
        // Crear un objeto ClassRoom con nombres automáticos
        int numberOfStudents = 20; // Número de alumnos
        int numberOfSubjects = 6; // Número de materias
        this.c = new ClassRoom(numberOfStudents, numberOfSubjects);
    }

    /**
     * Método que crea un menú con las debidas opciones para ver la tabla de notas, las notas de los estudiantes, 
     * las notas de las asignaturas, la media global de notas, la media de cada alumno, la media de cada asignatura,
     * y las notas mínimas y máximas de una materia.
     */
    public void showMenu() {
        Scanner sc = new Scanner(System.in);
        int option = 0;
        do {
            System.out.println("\n--- MENU ---");
            System.out.println("1. Show grades table");
            System.out.println("2. Show students grades");
            System.out.println("3. Show subjects grades");
            System.out.println("4. Show global average of grades");
            System.out.println("5. Show average of grades by students");
            System.out.println("6. Show average of grades by subjects");
            System.out.println("7. Show max and min grade of each subject");
            System.out.println("8. Modify grades");
            System.out.println("9. Exit");
            System.out.print("Please, choose an option: ");
            option = sc.nextInt();
            sc.nextLine(); // Limpiar el buffer

            switch (option) {
                case 1:
                    System.out.println("\n--- GRADES TABLE ---\n");
                    c.showTable();
                    break;
                case 2:
                    System.out.println("\n--- STUDENTS GRADES ---");
                    System.out.print("\nWhich student's grades do you want to see?: ");
                    int index = sc.nextInt() - 1; /*El -1 es para que el indice que el usuario escribe coincida bien con 
                    el índice del estudiante que quiere escoger, porque los usuarios no suelen saber que los indices empiezan en
                    0...*/
                    if (index >= 0 && index < c.getStudents().length) {
                        int[] grades = c.getStudentGrades(index);
                        System.out.println("Grades of " + c.getStudents()[index]);
                        for (int grade : grades) {
                            System.out.print(grade + " ");
                        }
                        System.out.println();
                    } else {
                        System.out.println("This student doesn't study here.");
                    }
                    break;
                case 3:
                    System.out.println("\n--- SUBJECTS GRADES ---");
                    System.out.print("\nWhich subject's grades do you want to see?: ");
                    int subjectNumber = sc.nextInt() - 1;
                    if (subjectNumber >= 0 && subjectNumber < c.getSubjects().length) {
                        int[] grades2 = c.getSubjectGrades(subjectNumber);
                        System.out.println("Grades of " + c.getSubjects()[subjectNumber]);
                        for (int grade : grades2) {
                            System.out.print(grade + " ");
                        }
                        System.out.println();
                    } else {
                        System.out.println("This subject doesn't exist.");
                    }
                    break;
                case 4:
                    System.out.println("\n--- GLOBAL GRADES AVERAGE ---");
                    System.out.println("\nGlobal grades avg: " + c.gradesAVG());
                    break;
                case 5:
                    System.out.println("\n--- STUDENTS GRADES AVERAGE ---");
                    System.out.print("\nWhich student's grades do you want to see?: ");
                    int studentNumber = sc.nextInt() - 1;
                    if (studentNumber >= 0 && studentNumber < c.getStudents().length) {
                        int average = c.studentsAVG(studentNumber);
                        System.out.println("Grades average of " + c.getStudents()[studentNumber]+ " " + average);
                    } else {
                        System.out.println("This student doesn't have grades.");
                    }
                    break;
                case 6:
                    System.out.println("\n--- SUBJECTS GRADES AVERAGE ---");
                    System.out.print("\nWhich subject's grades do you want to see?: ");
                    int subjectIndex = sc.nextInt() - 1;
                    if (subjectIndex >= 0 && subjectIndex < c.getSubjects().length) {
                        int avg = c.subjectsAVG(subjectIndex);
                        System.out.println("Grades average of " + c.getSubjects()[subjectIndex] + " " + avg);
                    } else {
                        System.out.println("This subject doesn't have grades.");
                    }
                    break;
                case 7:
                    System.out.println("\n--- MIN AND MAX GRADES ---");
                    System.out.print("\nWhich subject's higher/lower grade do you want to see?: ");
                    int index2 = sc.nextInt() - 1;
                    if (index2 >= 0 && index2 < c.getSubjects().length) {
                        int max = c.maxSubject(index2);
                        int min = c.minSubject(index2);
                        System.out.println("Higher grade of subject " + c.getSubjects()[index2] + ": " + max);
                        System.out.println("Lower grade of subject " + c.getSubjects()[index2] + ": " + min);
                    } else {
                        System.out.println("You didn't choose an existing subject.");
                    }
                    break;
                case 8:
                    System.out.println("\n--- MODIFY GRADES ---");
                    System.out.print("\nWhich student's grades you want to modify?: ");
                    int studentIndex = sc.nextInt() - 1;
                    System.out.print("Which subject's grades you want to modify?: ");
                    int subject = sc.nextInt();
                    System.out.print("Add the new grade: ");
                    int newGrade = sc.nextInt();
                    if (studentIndex >= 0 && studentIndex < c.getStudents().length && subject >= 0 && subject < c.getSubjects().length) {
                        c.setGrades(studentIndex, subject, newGrade);
                        System.out.println("New grade setted perfectly.");
                    } else {
                        System.out.println("Invalid student or subject index.");
                    }
                    break;
                case 9:
                    System.out.println("Bye-Bye!");
                    return;
                default:
                    System.out.println("Ups! Unvalid option.");
            }
        } while (option != 9); // Cambiado a option != 9
    }
}