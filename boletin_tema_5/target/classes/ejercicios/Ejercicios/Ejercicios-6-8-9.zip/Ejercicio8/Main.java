package ejercicios.Ejercicios.Ejercicio8;

public class Main {
    public static void main(String[] args) throws Exception{
        Collection col = new Collection();
        col.menu();
    }
}
